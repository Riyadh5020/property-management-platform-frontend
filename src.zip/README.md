# EstateOps — Property Management Console

A full-stack-ready property management frontend built with [TanStack Start](https://tanstack.com/start). It connects to a real backend API for authentication and admin operations, while using local-storage-backed demo data for property-management modules.

## Features

- **Building & Unit Management** — register buildings, units, amenities, and occupancy.
- **Tenant Management** — tenant profiles, documents, move-in/out tracking.
- **Lease & Contract Management** — lease agreements, renewals, rent escalation.
- **Rent & Billing** — invoices, utility charges, penalties, payment tracking.
- **Maintenance & Facility** — maintenance requests and scheduling.
- **Visitor & Security** — visitor logs, incident reporting.
- **Parking Management** — parking assignments and fees.
- **Staff Management** — staff records, duty scheduling, attendance.
- **Utility Management** — meter readings and bill splitting.
- **Owner/Investor Portal** — ownership records and profit-sharing.
- **Reports & Analytics** — occupancy, revenue, and maintenance cost charts.

## Tech Stack

- **Framework:** TanStack Start (React 19 + Vite 7)
- **Styling:** Tailwind CSS v4
- **State & Data:** React Query, localStorage-backed demo store
- **Charts:** Recharts
- **Icons:** Lucide React
- **Backend API:** Your own API at `http://localhost:8000/api/v1` (configurable)

## Prerequisites

- [Node.js](https://nodejs.org/) 18+ (or use [nvm](https://github.com/nvm-sh/nvm))
- [Bun](https://bun.sh/) (recommended) or npm
- A running backend API at `http://localhost:8000/api/v1`

## Installation

### 1. Clone the repository

```bash
git clone <repository-url>
cd <repository-name>
```

### 2. Install dependencies

Using Bun:

```bash
bun install
```

Using npm:

```bash
npm install
```

### 3. Configure the backend API (optional)

The app defaults to `http://localhost:8000/api/v1`. You can change this at runtime in **Settings**, or set it via environment variable:

```bash
# .env.local
VITE_API_BASE_URL=http://localhost:8000/api/v1
```

### 4. Start the development server

Using Bun:

```bash
bun run dev
```

Using npm:

```bash
npm run dev
```

The app will be available at [http://localhost:8080](http://localhost:8080).

## Available Scripts

| Script | Description |
|--------|-------------|
| `bun run dev` | Start the development server |
| `bun run build` | Build for production |
| `bun run start` | Start the production server |
| `bun run lint` | Run ESLint |
| `bun run format` | Format code with Prettier |

## Project Structure

```
src/
├── components/        # Reusable UI components and layouts
├── lib/               # API client, auth context, mock data, store
├── routes/            # TanStack Start file-based routes
├── styles.css         # Tailwind v4 theme and global styles
├── router.tsx         # Router configuration
└── server.ts          # SSR entry wrapper
```

## Authentication

- **Users** can register, verify email, log in, reset password, and manage their profile.
- **Admins** have a separate login flow and can manage users and administrators.
- All auth and admin operations call the real backend API.

## Demo Data

Property-management modules use seed data stored in `localStorage`. You can reset demo data from the **Settings** page.

## Deployment

Build the production bundle:

```bash
bun run build
```

Then start:

```bash
bun run start
```
